import java.util.Random;

public class Die {

    public Die() {
        System.out.println("The current side up for d6 is " + createDice(defaultType));
    }

    public Die(int dType) {
        System.out.println("The current side up for d20 is " + createDice(dType));
    }

    static int defaultType = 6;
    static int d20 = 20;
    static int percentile_d10 = 10;

    public static void main(String args[]) {
        System.out.println("Creating a default d6.....");
        System.out.println("Creating a d20.....");
        System.out.println("Creating percentile die (a special d10).....");
        new Die();
        new Die(d20);
        new Die(percentile_d10);
        roll();
    }

    private static int createDice(int noOfSides){
        return ((int) (Math.random() * noOfSides)) + 1;
    }

    public static void roll(){
        System.out.println("Rolling the d6.....");
        System.out.println("The new value is " + + createDice(defaultType));
        System.out.println("Rolling the d20.....");
        System.out.println("The current side up for d20 is " + + createDice(d20));
        System.out.println("Rolling the percentile.....");
        System.out.println("The new value is " + + createDice(percentile_d10));
        System.out.println("Creating 5 d6.....");
        System.out.println("YAHTZEE! It took " +  noOfRolls(5, defaultType) + " rolls");
    }

    public static int noOfRolls(int num, int noOfSides){
        int noOfRolls = 0;
        int value;

        do {
            value =  ((int) (Math.random() * noOfSides)) + 1;
            noOfRolls++;
        } while (num != value);

        return noOfRolls;
    }
}
